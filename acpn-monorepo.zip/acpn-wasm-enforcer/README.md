# ACPN WASM Enforcer
Deterministic execution gate.
