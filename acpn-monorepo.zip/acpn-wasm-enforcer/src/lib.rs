// WASM enforcement entrypoint
