# ACPN Core
Canonical specifications and schemas.
